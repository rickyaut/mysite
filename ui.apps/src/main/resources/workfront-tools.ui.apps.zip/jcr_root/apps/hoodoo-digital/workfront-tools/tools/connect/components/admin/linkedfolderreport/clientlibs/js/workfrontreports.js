$(document).ready(function() {

 $('#filter').click(function() {
        var refNumber = $('.ref-filter').val()
        if ( refNumber !== '' ) {
          var url = window.location.href;
          if (url.indexOf('?') > -1){
             url = url.replace(url.substring(url.indexOf("?")),"");
          }
          url += '?reference-number=' + refNumber;
          window.location.href = url;
        }
    });

    $('#clear').click(function() {
        var url = window.location.href;
        if (url.indexOf('reference-number=') > -1){
           url = url.replace(url.substring(url.indexOf("?")),"");
        }
        window.location.href = url;
    });

    $('.wf-create-linked-folder').on('click', function(e){

        var projectJson = $(this).data('wf-project');
        var subID = $(this).data('wf-subscriptionID');
         var prefix = $('.prefix-data').data("prefix");
        var update = {
            "subscriptionId":subID,
            "newState":projectJson
        }

        showWorking();

        $.ajax({
            url: prefix+"/createLinkedFolder",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify(update),
            success: function(){
                showSuccessAlert("Linked Folder Created");
                $('#workfront-tools-working').remove();
            },
            error: function(){
                showErrorAlert("Failed to create linked folder");
                $('#workfront-tools-working').remove();
            }
        });
    });

    $('.group-filter').change(function (event) {
        $('.group-filter').find('coral-select-item').each(function(idx, item){
            if ($(item).attr('selected')) {
                var url = window.location.href;
                if (url.indexOf('?') > -1){
                   url = url.replace(url.substring(url.indexOf("?")),"");
                }
                if ($(item).val() != "All Groups") {
                    url += '?group=' + $(item).val();
                }
                window.location.href = url;
            }
        })
    });
});

// ********** UTILS ********** //

var showSuccessAlert = function(text) {
    showAlert(text, 'Success');
};

var showErrorAlert = function(text) {
    showAlert(text, 'Error');
};

var showWarningAlert = function(text) {
    showAlert(text, 'Warning');
};

var showAlert = function(text, variant) {
    var dialog = new Coral.Dialog().set({
        id: 'workfront-tools-alert',
        closable: 'on',
        variant: variant.toLowerCase(),
        header: {
          innerHTML: variant
        },
        content: {
          innerHTML: text
        }
      });
    dialog.show();
    dialog.on('coral-overlay:close', function (event) {
        dialog.remove();
        location.reload();
    });
};

var showWorking = function(text, variant) {
    var dialog = new Coral.Dialog().set({
        id: 'workfront-tools-working',
        content: {
            innerHTML: "<coral-wait size=\"L\" centered>\n" +
                "</coral-wait>"
        }
    });
    dialog.show();
};
