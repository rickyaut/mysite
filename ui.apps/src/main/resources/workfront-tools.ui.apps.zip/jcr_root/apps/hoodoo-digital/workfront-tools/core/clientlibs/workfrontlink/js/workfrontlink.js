/* eslint no-useless-concat:0 */
(function(document, $) {
    "use strict";
    var activator = ".cq-damadmin-admin-workfront-link";

	$(document).ready(function(){
        $(activator).append("<coral-icon icon=\"/apps/hoodoo-digital/workfront-tools/core/clientlibs/assets/resources/workfront-icon.svg\" size=\"s\" style=\"float: left; width:18px\" class=\"workfront-icon\">");
    });
	
    $(document).on("foundation-contentloaded", function(e) {
        $(activator).attr('hidden', 'hidden');
    });

})(document, Granite.$);