$(document).ready(function () {

    var prefix = $('.scf-wizard-title').data("prefix");
    //Open credentials dialog on edit credentials button click
    $('#edit-credentials-button').click(function (event) {
        event.preventDefault();
        var dialog = document.querySelector('#edit-credentials-dialog');
        dialog.show();
    });

    if($('#is-enabled').val()) {
        //Open credentials dialog on page load if not configured already.
        apiKey = $('.credentials-workfrontApiKey').val();
        if (!apiKey) {
            var dialog = document.querySelector('#edit-credentials-dialog');
            Coral.commons.ready(dialog, function () {
                if (dialog) {
                    dialog.show();
                }
            });
        }
    } else {
        let dialog = document.querySelector('#ewfc-disabled-dialog');
        dialog.show();
    }

    //Generate AEM API Key on page load if empty.
    hasAemApiKey = $('.aemapikey').val();
    if (!hasAemApiKey) {
        var aemapikeyvalue = makeApiKey();
        var aemapikey = $('.aemapikey');
        aemapikey.val(aemapikeyvalue);
    }

    //Re-Generate AEM API Key on button click
    $('#regenerate-key-button').click(function () {
        var aemapikeyvalue = makeApiKey();
        var aemapikey = $('.aemapikey');

        $.ajax({
            method: 'POST',
            url: prefix+'/setaemapikey',
            data: {
                aemapikey: aemapikeyvalue
            },
            success: function (response) {
                if (response.status === 'error') {
                    showErrorAlert(response.error);
                } else {
                    console.log(response.success);
                    aemapikey.val(aemapikeyvalue);
                    aemapikey.prop("disabled", false);
                    aemapikey.prop("readonly", true);
                    aemapikey.prop("type", "text");
                    $('.aemapikey-copy-button').attr("disabled", false);
                    createDocCustomIntegration();
                }
            }
        });
    });

    $('#workfrontconnect-button').click(function () {
        workfrontConnect();
    });

    //Enable Subscribe to Workfront Events button on page load
    enableEventSubsButton();

    //Enable Subscribe to Workfront Events button on document provider config change
    // setDocumentProviderOnChange();

    //Delete Workfront subscription to events
    deleteIndividualEventSubscriptions();

    //Enable Linked Folder button on textfield change
    setLinkedFolderCustomFieldsOnChange();

    // Enable Linked Folder delete button
    if ($('#linked-folder-list').find('coral-multifield-item').length > 0) {
        $('#delete-linked-folder-configs').attr("disabled", false);
    }

    //Disable "Add new set of linked folder" config button if it surpassed threshold limit
    disableLinkedFolderAddButton();

});

// ********** WORKFRONT CONNECTION ********** //

var workfrontConnect = function() {

    var jcrtitle = $('.configuration-title').val();
    var apikey = $('.credentials-apikey').val();
    var domain = $('.credentials-domain').val();
    var apiendpointpath = $('.credentials-apiendpointpath').val();
    var url = $('.workfrontconnect-button').attr('data-url');
    var aemapikey = $('.aemapikey').val();
    var useBasicAuth = $('.credentials-useBasicAuth')[0].checked ? "on" : "off";

    //Get apiendpoint from domain
    var apiendpoint = domain;
    if (!apiendpoint.startsWith("http://") && !apiendpoint.startsWith("https://")) {
        apiendpoint = "https://" + apiendpoint;
    }
    if (apiendpoint.endsWith("/")) {
        apiendpoint = apiendpoint.substr(0, apiendpoint.length - 1);
    }

    $.ajax({
        method: 'POST',
        url: url,
        data: {
            jcrtitle: jcrtitle,
            apikey: apikey,
            apiendpoint: apiendpoint,
            apiendpointpath: apiendpointpath,
            aemapikey: aemapikey,
            useBasicAuth: useBasicAuth
        },
        async: false,
        success: function (response) {
            if (response.status === 'error') {
                showErrorAlert(response.error);
            } else {

                var workfrontApiKey = $('.credentials-workfrontApiKey');
                workfrontApiKey.val('••••••••••••••••••••••••••••••••');

                $('.credentials-apiendpoint').val(apiendpoint);

                var connectionSuccessfulAlert = $('.connection-successful');
                connectionSuccessfulAlert.prop("variant", "success");
                connectionSuccessfulAlert.find(".coral3-Alert-content").html("Connection to Workfront API was successful. Workfront API key retrieved.<br>Edit connection credentials to retrieve an API key with different credentials.");
                createDocCustomIntegration();
                refreshEventSubscriptionsTab();
                refreshLinkedFolderTab();
                enableNextSteps();
            }
        }
    });
};

// Create the document custom integration in workfront and then store the returned ID in workfrontconnect node
var createDocCustomIntegration = function () {
    var prefix = $('.scf-wizard-title').data("prefix");
    var jcrtitle = $('.configuration-title').val();
    var aemapikey = $('.aemapikey').val();
    var endpointDomain = $('.endpointDomain').val();
    $.ajax({
        method: 'POST',
        url: prefix + '/customIntegration',
        data: {
            jcrtitle: jcrtitle,
            aemapikey: aemapikey,
            endpointDomain: endpointDomain
        },
        async: false,
        success: function (response) {
            if (response.status === 'error') {
                showErrorAlert("Error creating custom integration in Workfront: " + response.error);
            } else {
                showSuccessAlert(response);
            }
        }
    });
};

//Enable next tabs once the connection is successful
var enableNextSteps = function () {
    $('.advanced-tab').attr("disabled", false);
    $('.eventsubs-tab').attr("disabled", false);
    $('.optionalfeatures-tab').attr("disabled", false);
}

var copyToClipboard = function () {
    var copyText = document.getElementsByClassName("aemapikey")[0];
    copyText.select();
    document.execCommand("copy");
    showSuccessAlert("AEM API Key copied to clipboard.");
}

var makeApiKey = function () {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (var i = 0; i < 32; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
};

// ********** ADVANCED TAB ********** //

var saveAdvancedSettings = function() {
    var prefix = $('.scf-wizard-title').data("prefix");
    var endpointDomain = $("#endpoint-domain").val();
    var storeDuplicateAsVersion = $('.store-duplicate-as-version')[0].checked ? "on" : "off";
    var updateMetadataWithVersion = $('.update-metadata-with-version')[0].checked ? "on" : "off";
    var setSpaceAsDash = $('.set-space-as-dash')[0].checked ? "on" : "off";
    var enableFolderMetadataTypes = $('.enable-folder-metadata-types')[0].checked ? "on" : "off";
    var isCloudService = $('.aem-as-cloud-service')[0].checked ? "on" : "off";

    var autoPublishAsset = $('.auto-publish-asset')[0].checked ? "on" : "off";
    var autoPublishCustomFormFieldValue = $('.auto-publish-custom-form-field-value').val();
    var autoPublishCustomFormField;
    $('.auto-publish-custom-form-field-dropdown').find('coral-select-item').each(function (idx, item) {
        if ($(item).attr('selected')) {
            autoPublishCustomFormField = $(item).attr('value');
        }
    });
    var brandPortalPublish = $('.brand-portal-publish')[0].checked ? "on" : "off";
    var updateMetadataOnDocumentUpdate = $('.update-metadata-on-document-update')[0].checked ? "on" : "off";
    $.ajax({
        method: 'POST',
        url: prefix+'/saveadvancedsettings',
        data: {
            endpointDomain: endpointDomain,
            storeDuplicateAsVersion: storeDuplicateAsVersion,
            updateMetadataWithVersion: updateMetadataWithVersion,
            setSpaceAsDash: setSpaceAsDash,
            enableFolderMetadataTypes: enableFolderMetadataTypes,
            autoPublishAsset: autoPublishAsset,
            autoPublishCustomFormField: autoPublishCustomFormField,
            autoPublishCustomFormFieldValue: autoPublishCustomFormFieldValue,
            brandPortalPublish: brandPortalPublish,
            updateMetadataOnDocumentUpdate: updateMetadataOnDocumentUpdate,
            isCloudService: isCloudService
        }, success: function (response) {
            if (response.status === 'error') {
                showErrorAlert(response.error);
            } else {
                showSuccessAlert("Advanced settings were saved successfully.");
                refreshEventSubscriptionsTab();
            }
        }
    });
}

// ********** EVENT SUBSCRIPTIONS ********** //

// ********** EVENT SUBSCRIPTIONS ********** //

//Enable event subscriptions button if document provider is set
var enableEventSubsButton = function() {
    $('.docproconfig-dropdown').find('coral-select-item').each(function(idx, item){
        if ($(item).attr('selected')) {
            $('#event-subscription-button').attr("disabled", false);
        }
    })
}

//Enable Workfront Event Subscriptions
var eventSubsEnable = function() {
    var prefix = $('.scf-wizard-title').data("prefix")
    var docProConfigId;
    $('.docproconfig-dropdown').find('coral-select-item').each(function(idx, item){
        if ($(item).attr('selected')) {
            docProConfigId = $(item).attr('value');
        }
    })

    $.ajax({
        method: 'POST',
        url: prefix+'/enableeventsubscriptions',
        data: {
            docProConfigId: docProConfigId
        },success: function(response){
            if(response.status === 'error'){
                showErrorAlert(response.error);
            } else {
                $('#event-subscription-button').html('Disable Workfront Event Subscriptions');
                $('#event-subscription-button').attr("onclick", "return eventSubsDisable()")
                showSuccessAlert("Workfront Event Subscriptions are now enabled. New subscriptions related to this AEM instance will appear in the first table.");
            }
        }
    });
}

//Disable Workfront Event Subscriptions
var eventSubsDisable = function() {
    var prefix = $('.scf-wizard-title').data("prefix")
    $.ajax({
        method: 'DELETE',
        url: prefix+'/disableeventsubscriptions',
        success: function(response){
            if(response.status === 'error'){
                showErrorAlert(response.error);
            }else{
                $('#event-subscription-button').html('Enable Workfront Event Subscriptions');
                $('#event-subscription-button').attr("onclick", "return eventSubsEnable()")
                showSuccessAlert("Event subscriptions are now disabled and all local event subscriptions have been deleted.");
                refreshEventSubscriptionsTab();

            }
        }
    });
    return false; //to prevent the form submit
}
const executeApiCall = function (settings, message) {
    return $.ajax(settings)
        .done(function (response) {
            if (response.status === 'error') {
                showErrorAlert(response.error);
            } else {
                showSuccessAlert(message);
            }
        });
};

//Enable Workfront Event Subscriptions
var commentSyncEnable = function() {
    var prefix = $('.scf-wizard-title').data("prefix")
    $.ajax({
        method: 'POST',
        url: prefix+'/commentSyncSubscription',
        data: null,
        success: function(response){
            if(response.status === 'error'){
                showErrorAlert(response.error);
            } else {
                $('#comment-sync-button').html('Disable Comment Sync Subscription');
                $('#comment-sync-button').attr("onclick", "return commentSyncDisable()")
                showSuccessAlert("Workfront Comment Sync is now enabled. This subscriptions will appear in the first table.");
                refreshEventSubscriptionsTab();
            }
        }
    });
    return false;
}

//Disable Workfront Event Subscriptions
var commentSyncDisable = function() {
    var prefix = $('.scf-wizard-title').data("prefix")
    $.ajax({
        method: 'DELETE',
        url: prefix+'/commentSyncSubscription',
        success: function(response){
            if(response.status === 'error'){
                showErrorAlert(response.error);
            }else{
                $('#comment-sync-button').html('Enable Comment Sync Subscription');
                $('#comment-sync-button').attr("onclick", "return commentSyncEnable()")
                showSuccessAlert("Workfront Comment Sync event subscriptions have been deleted.");
                refreshEventSubscriptionsTab();
            }
        }
    });
    return false; //to prevent the form submit
}

//Delete individual event subscriptions on link click
var deleteIndividualEventSubscriptions = function() {
    var prefix = $('.scf-wizard-title').data("prefix")
    $(".eventsubs-item a").click(function() {
        var elId = $(this).parents(".eventsubs-item").attr('id');
        $.ajax({
            method: 'DELETE',
            url: prefix+'/disableeventsubscriptions?id='+elId,
            success: function(response){
                if(response.status === 'error'){
                    showErrorAlert(response.error);
                }else{
                    showSuccessAlert("Subscription with ID " + elId + " was succesfully deleted.");
                    $("#"+elId).remove();
                }
            }
        });
    });
}


var refreshEventSubscriptionsTab = function() {
    $.ajax({
        url: "/apps/hoodoo-digital/workfront-tools/tools/connect/content/configurations/editworkfrontconfig/jcr:content/content/items/editworkfrontconfig.eventsubscriptions.html",
        success: function (result) {
            $("#eventsubs-container").replaceWith($(result).find('#eventsubs-container'));
        }
    });
}



// ********** LINKED FOLDER ********** //

var refreshLinkedFolderTab = function () {
    $.ajax({
        url: "/apps/hoodoo-digital/workfront-tools/tools/connect/content/configurations/editworkfrontconfig/jcr:content/content/items/editworkfrontconfig.linkedfolder.html",
        success: function (result) {
            $("#linkedfolder-container").replaceWith($(result));
            setLinkedFolderCustomFieldsOnChange();
        }
    });
}

//Verify if "Add new set of linked folder" needs to be enabled/disabled
var disableLinkedFolderAddButton = function () {
    let prefix = $('.scf-wizard-title').data("prefix")
    let linkedFolderAddNewButton = document.querySelector('#linked-folder-add-new-button')
    $.ajax({
        method: 'GET',
        url: prefix + '/enablelinkedfolder',
        success: function (response) {
            if (response.message === 'true') {
                linkedFolderAddNewButton.setAttribute("disabled", "true");
            }
        }
    });
}

//Enable automatic creation of project linked folder
var linkedFolderEnable = function(btn) {
    linkedFolderUpdate(btn,true);
}


//Update automatic creation of project linked folder configuration and enable
var linkedFolderUpdate = function(btn, enable) {
    var prefix = $('.scf-wizard-title').data("prefix")
    var multiItem = $(btn).closest('coral-multifield-item');
    var uuid = multiItem.find('.linked-folder-uuid').val();
    var linkedFolderParentPath  = multiItem.find('.linked-folder-parent-path-field').val();
    var linkedFolderStructureField = multiItem.find('.linked-folder-structure-field').val();
    var linkedFolderStructureTitle  = multiItem.find('.linked-folder-structure-title')[0].checked ? "on" : "off";
    var subFoldersCustomFormField;
    multiItem.find('.subfolders-custom-form-field-dropdown').find('coral-select-item').each(function (idx, item) {
        if ($(item).attr('selected')) {
            subFoldersCustomFormField = $(item).attr('value');
        }
    });
    var subFoldersCustomFormFieldValue  = multiItem.find('.subfolders-custom-form-field-value').val();
    var linkedFolderProjectStatus;
    multiItem.find('.project-status-dropdown').find('coral-select-item').each(function (idx, item) {
        if ($(item).attr('selected')) {
            linkedFolderProjectStatus = $(item).attr('value');
        }
    });
    var linkedFolderCustomFormField;
    multiItem.find('.custom-form-field-dropdown').find('coral-select-item').each(function (idx, item) {
        if ($(item).attr('selected')) {
            linkedFolderCustomFormField = $(item).attr('value');
        }
    });
    var linkedFolderCustomFormFieldValue  = multiItem.find('.custom-form-field-value').val();
    var subfoldersMultifield = multiItem.find("[data-granite-coral-multifield-subfolder]")
    var subfoldersCount = subfoldersMultifield.children('coral-multifield-item').length;
    var linkedFolderSubfolders = "";
    for (var i = 0; i < subfoldersCount; i++) {
        linkedFolderSubfolders += (linkedFolderSubfolders.length > 0 ? "," : "") + encodeURIComponent(subfoldersMultifield.find("[name*='linkedFolderSubfolders/item" + i + "/subfolder']").val());
    }
    var portfoliosMultifield = multiItem.find("[data-granite-coral-multifield-linkedFolderPortfolios]");
    var portfoliosCount = portfoliosMultifield.children('coral-multifield-item').length;
    var linkedFolderPortfolios = "";
    for (var i = 0; i < portfoliosCount; i++) {
        var portfolioID;
        portfoliosMultifield.find("[name*='linkedFolderPortfolios/item" + i + "/portfolio']").find('coral-select-item').each(function (idx, item) {
            if ($(item).attr('selected')) {
                portfolioID = $(item).attr('value');
            }
        });
        linkedFolderPortfolios += (linkedFolderPortfolios.length > 0 ? "," : "") + portfolioID;
    }

    $.ajax({
        method: 'POST',
        url: prefix+'/enablelinkedfolder',
        data: {
            uuid:uuid,
            linkedFolderCustomFields: linkedFolderStructureField,
            linkedFolderParentPath: linkedFolderParentPath,
            linkedFolderProjectStatus: linkedFolderProjectStatus,
            linkedFolderStructureTitle: linkedFolderStructureTitle,
            linkedFolderSubfolders: linkedFolderSubfolders,
            subfoldersCustomFormField: subFoldersCustomFormField,
            subfoldersCustomFormFieldValue: subFoldersCustomFormFieldValue,
            linkedFolderPortfolios: linkedFolderPortfolios,
            linkedFolderCustomFormField: linkedFolderCustomFormField,
            linkedFolderCustomFormFieldValue: linkedFolderCustomFormFieldValue,
            enable: enable
        },success: function(response){
            if(response.status === 'error'){
                showErrorAlert(response.error);
            } else {
                if (enable) {
                    showSuccessAlert("Automatic creation of linked folders is now enabled. Event subscriptions have been created successfully.");
                    refreshEventSubscriptionsTab();
                    location.reload();
                } else {
                    showSuccessAlert("Automatic creation of linked folders configuration was updated successfully.");
                    refreshEventSubscriptionsTab();
                }
            }
        }
    });
}

// Disable automatic creation of project linked folder and delete all configurations
var linkedFolderDisable = function(btn, isDelete) {
    var prefix = $('.scf-wizard-title').data("prefix")
    var multiItem = $(btn).closest('coral-multifield-item');
    var uuid = multiItem.find('.linked-folder-uuid').val();
    uuid = uuid === undefined ? "":uuid
    $.ajax({
        method: 'POST',
        url: prefix+'/disablelinkedfolder',
        data: {
            uuid:uuid,
            isDelete:isDelete
        },
        success: function(response){
            if(response.status === 'error'){
                showErrorAlert(response.error);
            } else {
                if (isDelete) {
                    showSuccessAlert("Automatic creation of linked folders is now disabled. Event subscriptions have been deleted successfully.");
                }
                else
                {
                    showSuccessAlert("Automatic creation of linked folders is now disabled. Event subscriptions have been disabled successfully.");
                }
                refreshEventSubscriptionsTab();
                location.reload();
            }
        }
    });
    return false; //to prevent the form submit
}


var setLinkedFolderCustomFieldsOnChange = function () {
    $('#linked-folder-custom-fields').change(function () {
        if ($('#linked-folder-custom-fields').val()) {
            $('#linked-folder-button').attr("disabled", false);
        } else {
            $('#linked-folder-button').attr("disabled", true);
        }
    });
}

// ********** UTILS ********** //

var showSuccessAlert = function (text) {
    showAlert(text, 'Success');
}

var showErrorAlert = function (text) {
    showAlert(text, 'Error');
}

var showWarningAlert = function (text) {
    showAlert(text, 'Warning');
}

var showAlert = function (text, variant) {
    var dialog = new Coral.Dialog().set({
        id: 'workfront-tools-alert',
        closable: 'on',
        variant: variant.toLowerCase(),
        header: {
            innerHTML: variant
        },
        content: {
            innerHTML: text
        }
    });
    dialog.show();
    dialog.on('coral-overlay:close', function (event) {
        dialog.remove();
    });
}

//Generate event subscription report
var generateSubReport = async function () {

    const btn = document.querySelector(".sub-report-generation-button");
    btn.classList.add("sub-report-generation-button--spinner");
    let prefix = $('.scf-wizard-title').data("prefix");

    function replacer(key,value)
    {
        if (key=="authToken" || key=="customerId" || key=="objId" || key=="local_aem_subscription") return undefined;
        else return value;
    }

    await fetch(prefix + '/generateeventsubscription')
        .then((response) => response.json())
        .then(data => {

            if(data.status === "error")
            {
                showErrorAlert(data.error);
                btn.classList.remove("sub-report-generation-button--spinner");
                return false;
            }

            else
            {
                const blob = new Blob([JSON.stringify(data, replacer, 2)], {type: "text/plain"});
                const url = window.URL.createObjectURL(blob);
                window.open(url);
                btn.classList.remove("sub-report-generation-button--spinner");
                window.URL.revokeObjectURL(url);
            }

        }).catch(error => {
            console.log(error);
            btn.classList.remove("sub-report-generation-button--spinner");
        });
}
